
import './App.css';

import Board from "./pages/Board"
import { Fragment } from 'react';

function App() {
  return (
    <Fragment>
      <Board />
    </Fragment>
  );
}

export default App;
